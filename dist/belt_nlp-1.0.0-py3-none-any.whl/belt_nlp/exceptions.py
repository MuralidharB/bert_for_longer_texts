class InconsistentSplittingParamsException(Exception):
    pass
